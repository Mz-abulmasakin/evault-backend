
/**
 * =========================================================
 * ADD PROVIDER STATUS TO IDENTITY REQUESTS
 * =========================================================
 *
 * Migration:
 * 1785850845702
 *
 * This migration is required because the original
 * identity_requests migration has already been executed.
 *
 * DO NOT modify the original migration.
 */

export async function up(db) {
  await db.query(`
    ALTER TABLE identity_requests
    ADD COLUMN IF NOT EXISTS provider_status VARCHAR(50)
  `);

  await db.query(`
    CREATE INDEX IF NOT EXISTS idx_identity_requests_provider_status
    ON identity_requests(provider_status)
  `);
}

export async function down(db) {
  await db.query(`
    DROP INDEX IF EXISTS idx_identity_requests_provider_status
  `);

  await db.query(`
    ALTER TABLE identity_requests
    DROP COLUMN IF EXISTS provider_status
  `);
}

