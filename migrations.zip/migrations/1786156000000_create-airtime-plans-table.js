 /**
 * @type {import('node-pg-migrate').MigrationBuilder}
 */

export const up = (pgm) => {
  pgm.createTable("airtime_plans", {
    id: {
      type: "uuid",
      primaryKey: true,
      default: pgm.func("gen_random_uuid()"),
    },

    provider: {
      type: "varchar(50)",
      notNull: true,
      default: "ALRAHUZ",
    },

    provider_plan_id: {
      type: "integer",
      notNull: true,
    },

    network_id: {
      type: "integer",
      notNull: true,
    },

    network_name: {
      type: "varchar(30)",
      notNull: true,
    },

    amount: {
      type: "numeric(18,2)",
      notNull: true,
    },

    is_active: {
      type: "boolean",
      notNull: true,
      default: true,
    },

    metadata: {
      type: "jsonb",
      notNull: true,
      default: "{}",
    },

    created_at: {
      type: "timestamp",
      notNull: true,
      default: pgm.func("CURRENT_TIMESTAMP"),
    },

    updated_at: {
      type: "timestamp",
      notNull: true,
      default: pgm.func("CURRENT_TIMESTAMP"),
    },
  });

  pgm.addConstraint(
    "airtime_plans",
    "airtime_plans_provider_provider_plan_id_unique",
    {
      unique: ["provider", "provider_plan_id"],
    }
  );

  pgm.createIndex("airtime_plans", "network_id");
  pgm.createIndex("airtime_plans", "network_name");
  pgm.createIndex("airtime_plans", "is_active");
};

export const down = (pgm) => {
  pgm.dropTable("airtime_plans");
};