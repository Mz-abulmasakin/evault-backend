export async function up(db) {
  await db.query(`
    CREATE TABLE IF NOT EXISTS identity_requests (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

      user_id UUID NOT NULL
        REFERENCES users(id)
        ON DELETE CASCADE,

      request_type VARCHAR(20) NOT NULL,
      identifier_hash VARCHAR(64) NOT NULL,

      provider VARCHAR(50) NOT NULL DEFAULT 'instantipe',
      provider_reference VARCHAR(100),

      validation_type VARCHAR(20),
      slip_type VARCHAR(20),

      amount NUMERIC(18, 2) NOT NULL DEFAULT 0,

      status VARCHAR(30) NOT NULL DEFAULT 'PENDING',

      provider_status VARCHAR(50),

      document_url TEXT,
      document_expires_at TIMESTAMP,

      provider_response JSONB,

      failure_code VARCHAR(100),
      failure_message TEXT,

      transaction_reference VARCHAR(100),

      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

      CONSTRAINT identity_requests_type_check
        CHECK (
          request_type IN ('NIN', 'BVN')
        ),

      CONSTRAINT identity_requests_status_check
        CHECK (
          status IN (
            'PENDING',
            'PROCESSING',
            'SUCCESS',
            'FAILED'
          )
        )
    );
  `);

  await db.query(`
    CREATE INDEX IF NOT EXISTS idx_identity_requests_user_id
    ON identity_requests(user_id);
  `);

  await db.query(`
    CREATE INDEX IF NOT EXISTS idx_identity_requests_provider_reference
    ON identity_requests(provider_reference);
  `);

  await db.query(`
    CREATE INDEX IF NOT EXISTS idx_identity_requests_identifier_hash
    ON identity_requests(identifier_hash);
  `);

  await db.query(`
    CREATE INDEX IF NOT EXISTS idx_identity_requests_status
    ON identity_requests(status);
  `);

  await db.query(`
    CREATE INDEX IF NOT EXISTS idx_identity_requests_created_at
    ON identity_requests(created_at DESC);
  `);
}

export async function down(db) {
  await db.query(`
    DROP TABLE IF EXISTS identity_requests;
  `);
}