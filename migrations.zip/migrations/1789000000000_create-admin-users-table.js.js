/**
 * =========================================================
 * CREATE ADMIN USERS TABLE
 * =========================================================
 *
 * Admin authentication is intentionally separated from
 * the normal customer "users" table.
 *
 * Customer:
 *     users
 *
 * Administrators:
 *     admin_users
 *
 * =========================================================
 */

/**
 * @type {import('node-pg-migrate').ColumnDefinitions | undefined}
 */
export const shorthands = undefined;

export const up = (pgm) => {
  pgm.createTable("admin_users", {
    id: {
      type: "uuid",
      primaryKey: true,
      default: pgm.func("gen_random_uuid()"),
    },

    username: {
      type: "varchar(50)",
      notNull: true,
      unique: true,
    },

    email: {
      type: "varchar(150)",
      notNull: true,
      unique: true,
    },

    full_name: {
      type: "varchar(150)",
      notNull: true,
    },

    password_hash: {
      type: "text",
      notNull: true,
    },

    role: {
      type: "varchar(30)",
      notNull: true,
      default: "ADMIN",
    },

    status: {
      type: "varchar(20)",
      notNull: true,
      default: "ACTIVE",
    },

    last_login_at: {
      type: "timestamp with time zone",
    },

    created_at: {
      type: "timestamp with time zone",
      notNull: true,
      default: pgm.func("CURRENT_TIMESTAMP"),
    },

    updated_at: {
      type: "timestamp with time zone",
      notNull: true,
      default: pgm.func("CURRENT_TIMESTAMP"),
    },

    deleted_at: {
      type: "timestamp with time zone",
    },
  });

  /**
   * -------------------------------------------------------
   * INDEXES
   * -------------------------------------------------------
   */

  pgm.createIndex(
    "admin_users",
    "email",
    {
      name: "idx_admin_users_email",
    }
  );

  pgm.createIndex(
    "admin_users",
    "username",
    {
      name: "idx_admin_users_username",
    }
  );

  pgm.createIndex(
    "admin_users",
    "status",
    {
      name: "idx_admin_users_status",
    }
  );

  pgm.createIndex(
    "admin_users",
    "role",
    {
      name: "idx_admin_users_role",
    }
  );
};

export const down = (pgm) => {
  pgm.dropTable("admin_users");
};