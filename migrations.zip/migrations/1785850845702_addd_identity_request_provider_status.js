export async function up(db) {
  await db.query(`
    ALTER TABLE identity_requests
    ADD COLUMN IF NOT EXISTS provider_status VARCHAR(50);
  `);

  await db.query(`
    CREATE INDEX IF NOT EXISTS idx_identity_requests_provider_status
    ON identity_requests(provider_status);
  `);
}

export async function down(db) {
  await db.query(`
    DROP INDEX IF EXISTS idx_identity_requests_provider_status;
  `);

  await db.query(`
    ALTER TABLE identity_requests
    DROP COLUMN IF EXISTS provider_status;
  `);
}