export const shorthands = undefined;

export async function up(pgm) {
  pgm.createTable("identity_verifications", {
    id: {
      type: "uuid",
      primaryKey: true,
      default: pgm.func("gen_random_uuid()"),
    },

    user_id: {
      type: "uuid",
      notNull: true,
      references: "users(id)",
      onDelete: "CASCADE",
      unique: true,
    },

    bvn: {
      type: "varchar(11)",
      notNull: false,
    },

    nin: {
      type: "varchar(11)",
      notNull: false,
    },

    bvn_verified: {
      type: "boolean",
      notNull: true,
      default: false,
    },

    nin_verified: {
      type: "boolean",
      notNull: true,
      default: false,
    },

    status: {
      type: "varchar(20)",
      notNull: true,
      default: "PENDING",
    },

    created_at: {
      type: "timestamp",
      notNull: true,
      default: pgm.func("CURRENT_TIMESTAMP"),
    },

    updated_at: {
      type: "timestamp",
      notNull: true,
      default: pgm.func("CURRENT_TIMESTAMP"),
    },
  });

  pgm.createIndex(
    "identity_verifications",
    "user_id"
  );
}

export async function down(pgm) {
  pgm.dropTable(
    "identity_verifications"
  );
}