export async function up(db) {
  await db.query(`
    CREATE TABLE IF NOT EXISTS identity_requests (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

      user_id UUID NOT NULL
        REFERENCES users(id)
        ON DELETE CASCADE,

      identity_type VARCHAR(30) NOT NULL,

      provider VARCHAR(50) NOT NULL,

      provider_reference VARCHAR(150),

      identifier_hash VARCHAR(255) NOT NULL,

      validation_type VARCHAR(30),

      slip_type VARCHAR(30),

      amount NUMERIC(18, 2) NOT NULL DEFAULT 0,

      currency VARCHAR(10) NOT NULL DEFAULT 'NGN',

      status VARCHAR(30) NOT NULL DEFAULT 'PENDING',

      transaction_reference VARCHAR(100),

      idempotency_key VARCHAR(255),

      ownership_confirmed BOOLEAN NOT NULL DEFAULT FALSE,

      result JSONB,

      document_url TEXT,

      document_expires_at TIMESTAMPTZ,

      error_code VARCHAR(100),

      error_message TEXT,

      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

      CONSTRAINT uq_identity_requests_provider_reference
        UNIQUE (provider, provider_reference),

      CONSTRAINT uq_identity_requests_idempotency_key
        UNIQUE (idempotency_key)
    );

    CREATE INDEX IF NOT EXISTS idx_identity_requests_user_id
      ON identity_requests(user_id);

    CREATE INDEX IF NOT EXISTS idx_identity_requests_status
      ON identity_requests(status);

    CREATE INDEX IF NOT EXISTS idx_identity_requests_identity_type
      ON identity_requests(identity_type);

    CREATE INDEX IF NOT EXISTS idx_identity_requests_created_at
      ON identity_requests(created_at);

    CREATE INDEX IF NOT EXISTS idx_identity_requests_provider_reference
      ON identity_requests(provider_reference);
  `);
}

export async function down(db) {
  await db.query(`
    DROP TABLE IF EXISTS identity_requests;
  `);
}