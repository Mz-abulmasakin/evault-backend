import db from "../../src/config/database.js";

const migrationName =
  "1785850845701_create_identity_requests";

async function up(client = db) {
  await client.query(`
    CREATE TABLE IF NOT EXISTS identity_requests (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

      user_id UUID NOT NULL
        REFERENCES users(id)
        ON DELETE CASCADE,

      identity_type VARCHAR(10) NOT NULL
        CHECK (
          identity_type IN ('NIN', 'BVN')
        ),

      provider VARCHAR(50) NOT NULL
        DEFAULT 'INSTANTIPE',

      provider_reference VARCHAR(100),

      identifier_hash VARCHAR(128) NOT NULL,

      validation_type VARCHAR(20),

      slip_type VARCHAR(20),

      amount NUMERIC(18,2) NOT NULL
        DEFAULT 0,

      currency VARCHAR(10) NOT NULL
        DEFAULT 'NGN',

      status VARCHAR(20) NOT NULL
        DEFAULT 'PENDING'
        CHECK (
          status IN (
            'PENDING',
            'PROCESSING',
            'SUCCESS',
            'FAILED'
          )
        ),

      transaction_reference VARCHAR(100),

      idempotency_key VARCHAR(150),

      ownership_confirmed BOOLEAN NOT NULL
        DEFAULT FALSE,

      result JSONB,

      document_url TEXT,

      document_expires_at TIMESTAMP,

      error_code VARCHAR(100),

      error_message TEXT,

      created_at TIMESTAMP NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

      updated_at TIMESTAMP NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

      CONSTRAINT identity_requests_provider_reference_unique
        UNIQUE (
          provider,
          provider_reference
        ),

      CONSTRAINT identity_requests_idempotency_unique
        UNIQUE (
          idempotency_key
        )
    );

    CREATE INDEX IF NOT EXISTS
      idx_identity_requests_user_id
      ON identity_requests(user_id);

    CREATE INDEX IF NOT EXISTS
      idx_identity_requests_type
      ON identity_requests(identity_type);

    CREATE INDEX IF NOT EXISTS
      idx_identity_requests_status
      ON identity_requests(status);

    CREATE INDEX IF NOT EXISTS
      idx_identity_requests_created_at
      ON identity_requests(created_at DESC);

    CREATE INDEX IF NOT EXISTS
      idx_identity_requests_identifier_hash
      ON identity_requests(identifier_hash);
  `);

  console.log(
    "identity_requests table created."
  );
}

async function down(client = db) {
  await client.query(`
    DROP TABLE IF EXISTS identity_requests;
  `);

  console.log(
    "identity_requests table dropped."
  );
}

export default {
  migrationName,
  up,
  down,
};